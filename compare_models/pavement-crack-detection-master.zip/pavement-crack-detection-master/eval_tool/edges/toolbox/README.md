Documentation: https://pdollar.github.io/toolbox/
